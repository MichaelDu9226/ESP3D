
https://www.manual.rotrics.com/accessories/touchscreen