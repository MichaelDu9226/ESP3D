The voice recognition is a function under development, you can experience it by config function_switch on in voice.json
You should set the wifi config in wifi.json and get the token from https://www.manual.rotrics.com/accessories/touchscreen
Warning:When this function is opened，the other functions will become unstable, like send big size gcode file .etc
